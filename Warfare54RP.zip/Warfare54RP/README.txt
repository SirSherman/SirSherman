Hello there, to who ever is reading this, I have something for you.
So, here are my policies regarding this addon.

1. You CAN NOT use my assets without my permission.
My assests include textures, models, code, items, recipes etc.
You can only use them if you have my personal approval. If you want to contect me, you
can do that by either 
DISCORD: https://discord.gg/amKYWWN962
EMAIL: zombeeplays6@gmail.com
DISCORD USERNAME: Sir. Sherman-8#5131

2.You do not have permission to re-upload my addon on any website. 
If you want my addon uploaded on a website, refer to my contacts above.
I will take action when I find out about anyome uploading my addon.

3. DO NOT take credit for my addon.
This addon was made by me, and only me. I will take strict action against anyone who doesn't accept my terms.


